==============
EO-LDAS ng
==============
:Info: EO-LDAS new generation: a new take on the EO-LDAS codebase
:Author: J Gomez-Dans <j.gomez-dans@ucl.ac.uk>
:Date: 2013-07-01 16:00:00 +0000 
:Description: README file


EO-LDAS
-------

This repository contains a rationalisation of the original EO-LDAS codebase. 
